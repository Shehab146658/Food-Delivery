-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2018 at 10:16 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `cashondelivery`
--

CREATE TABLE `cashondelivery` (
  `amount` float NOT NULL,
  `customerid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cashondelivery`
--

INSERT INTO `cashondelivery` (`amount`, `customerid`) VALUES
(500, 'A1');

-- --------------------------------------------------------

--
-- Table structure for table `creditcard`
--

CREATE TABLE `creditcard` (
  `creditcardno` varchar(20) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `balance` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `midname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `phonenumber` varchar(20) NOT NULL,
  `homenumber` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `firstname`, `midname`, `lastname`, `phonenumber`, `homenumber`, `address`, `username`, `password`) VALUES
('A1', 'mekhemer', '0100', '0100', 'ismail', '09000', 'bata', 'tabamo3', 'bata'),
('A2', 'lala', 'land', 'lol', '222222', '0999', 'hell', 'bala7', 'la'),
('A3', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l'),
('A33', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q'),
('A4', 'e', 'e', 'e', 'e', 'e', 'e', 'e', 'e');

-- --------------------------------------------------------

--
-- Table structure for table `customerlogin`
--

CREATE TABLE `customerlogin` (
  `customerid` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerlogin`
--

INSERT INTO `customerlogin` (`customerid`, `username`, `password`) VALUES
('4A1', 'o', 'o'),
('A1', 'tabamo3', 'bata'),
('A2', 'bala7', 'la'),
('A3', 'l', 'l'),
('A33', 'q', 'q'),
('A4', 'e', 'e');

-- --------------------------------------------------------

--
-- Table structure for table `managerlogin`
--

CREATE TABLE `managerlogin` (
  `manager_id` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `managerlogin`
--

INSERT INTO `managerlogin` (`manager_id`, `username`, `password`) VALUES
('1', 'fatma', '12345fatma');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` varchar(20) NOT NULL,
  `resturant_id` varchar(500) NOT NULL,
  `date_update` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `resturant_id`, `date_update`) VALUES
('1752a', '1', '2018-04-11'),
('21c', '3', '2018-03-05'),
('23m', '2', '2018-03-14'),
('284b', '4', '2018-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `menu_item`
--

CREATE TABLE `menu_item` (
  `item_id` varchar(500) NOT NULL,
  `menu_id` varchar(20) NOT NULL,
  `name` varchar(80) NOT NULL,
  `type` varchar(100) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_item`
--

INSERT INTO `menu_item` (`item_id`, `menu_id`, `name`, `type`, `description`, `price`) VALUES
('142854aa', '21c', 'vsdgbsdgs', 'xvsgsdga', 'bdbagwg', 10),
('1485r', '284b', 'nryjeeh', 'hrthh', 'nyrh3aeyyWGEHETHTH', 50),
('bbgbfg', '21c', 'dberbge', 'bdger', 'bdhewGsdsgwrgrgwrgwgw', 15),
('brrh', '23m', 'dfbethbhsh', 'behwsgagsdbsn', 'bdthehefasewsegwg', 15);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `offer_id` varchar(200) NOT NULL,
  `resturant_id` varchar(500) NOT NULL,
  `production_date` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `value` varchar(101) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`offer_id`, `resturant_id`, `production_date`, `description`, `value`) VALUES
('115d', '3', '21/2/2011', 'erf4rfcedeeferfe', '15%'),
('1425a', '3', '21/8/2017', 'eervrverveceevev', '50%'),
('151f2d', '1', '2/11/2016', 'evrvcbuebevvv', '2%'),
('1754ff', '2', '1/1/2016', '43t34t', '14%');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderId` varchar(20) NOT NULL,
  `customerID` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paypal`
--

CREATE TABLE `paypal` (
  `customerid` varchar(20) NOT NULL,
  `accountnumber` varchar(20) NOT NULL,
  `balance` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paypal`
--

INSERT INTO `paypal` (`customerid`, `accountnumber`, `balance`) VALUES
('A2', '15384', 8000);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `restaurantID` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phoneNo` varchar(12) NOT NULL,
  `hotline` varchar(6) NOT NULL,
  `address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`restaurantID`, `name`, `phoneNo`, `hotline`, `address`) VALUES
(1, 'aswwww', 'shehab', 'shehab', 'rehab'),
(2, 'shehab', 'shehab', 'shehab', 'shehab'),
(3, 's', 's', 's', 's'),
(4, 'shehab', 'shehab', 'shehab', 'rehab'),
(12, 'sf', 'fw', 'sq', 'sa'),
(13, 'asds', 'dasd', 'dsad', 'dsa');

-- --------------------------------------------------------

--
-- Table structure for table `restaurantadmin`
--

CREATE TABLE `restaurantadmin` (
  `managerID` varchar(20) NOT NULL,
  `restaurantID` int(20) NOT NULL,
  `firstName` varchar(10) NOT NULL,
  `midName` varchar(10) NOT NULL,
  `lastName` varchar(10) NOT NULL,
  `address` varchar(20) NOT NULL,
  `homeNo` varchar(20) NOT NULL,
  `phoneNo` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurantadmin`
--

INSERT INTO `restaurantadmin` (`managerID`, `restaurantID`, `firstName`, `midName`, `lastName`, `address`, `homeNo`, `phoneNo`, `username`, `password`) VALUES
('1', 1, 'shehab', 'shehab', 'shehab', 'shehab', 'shehab', 'shehab', 'shehab', 'shehab');

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `cartid` varchar(20) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `itemid` varchar(20) NOT NULL,
  `notes` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoppingcart`
--

INSERT INTO `shoppingcart` (`cartid`, `customerid`, `itemid`, `notes`, `quantity`) VALUES
('scA1', 'A1', '5', '  ', 5),
('scA1', 'A1', '5', '  ', 5);

-- --------------------------------------------------------

--
-- Table structure for table `systemmanager`
--

CREATE TABLE `systemmanager` (
  `manager_id` varchar(2) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `midName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `homeNumber` varchar(30) NOT NULL,
  `phoneNumber` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `systemmanager`
--

INSERT INTO `systemmanager` (`manager_id`, `Address`, `firstName`, `midName`, `lastName`, `homeNumber`, `phoneNumber`, `username`, `password`) VALUES
('1', 'nasrcity', 'fatma', 'elzahraa', 'mekhemer', '68667768', '0111435535', 'fatma', '12345fatma');

-- --------------------------------------------------------

--
-- Table structure for table `system_admin`
--

CREATE TABLE `system_admin` (
  `admin_id` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `mid_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `adress` varchar(30) NOT NULL,
  `home_number` varchar(30) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `system_admin`
--

INSERT INTO `system_admin` (`admin_id`, `first_name`, `mid_name`, `last_name`, `adress`, `home_number`, `phone_number`, `username`, `password`) VALUES
('11', 'ahmed', 'mohamed', 'ahmed', 'maadi', '829749472', '0183383', 'ahmed', 'ahmed123'),
('13', 'perry', 'ahmed', 'fawzy', 'nasrcity', '139739717', '01838484', 'perry', 'perry123'),
('2', 'lala', 'land', '7asanen', 'ehohwiihe', '739792732', '32323832', 'lala', 'lala123');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`username`, `password`) VALUES
('hassan', 'hassanola');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashondelivery`
--
ALTER TABLE `cashondelivery`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `creditcard`
--
ALTER TABLE `creditcard`
  ADD PRIMARY KEY (`customerid`),
  ADD UNIQUE KEY `customerid` (`customerid`),
  ADD UNIQUE KEY `customerid_2` (`customerid`),
  ADD UNIQUE KEY `creditcardno` (`creditcardno`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `customerlogin`
--
ALTER TABLE `customerlogin`
  ADD PRIMARY KEY (`customerid`),
  ADD UNIQUE KEY `customerid` (`customerid`);

--
-- Indexes for table `managerlogin`
--
ALTER TABLE `managerlogin`
  ADD PRIMARY KEY (`manager_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `menu_item`
--
ALTER TABLE `menu_item`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `paypal`
--
ALTER TABLE `paypal`
  ADD PRIMARY KEY (`customerid`),
  ADD UNIQUE KEY `customerid` (`customerid`),
  ADD UNIQUE KEY `customerid_2` (`customerid`),
  ADD UNIQUE KEY `accountnumber` (`accountnumber`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`restaurantID`),
  ADD UNIQUE KEY `restaurantID_2` (`restaurantID`),
  ADD KEY `restaurantID` (`restaurantID`);

--
-- Indexes for table `restaurantadmin`
--
ALTER TABLE `restaurantadmin`
  ADD PRIMARY KEY (`managerID`),
  ADD KEY `restaurantID` (`restaurantID`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD KEY `carttocustomer` (`customerid`);

--
-- Indexes for table `systemmanager`
--
ALTER TABLE `systemmanager`
  ADD PRIMARY KEY (`manager_id`);

--
-- Indexes for table `system_admin`
--
ALTER TABLE `system_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `id` FOREIGN KEY (`id`) REFERENCES `customerlogin` (`customerid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `managerlogin`
--
ALTER TABLE `managerlogin`
  ADD CONSTRAINT `managerlogin_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `systemmanager` (`manager_id`);

--
-- Constraints for table `menu_item`
--
ALTER TABLE `menu_item`
  ADD CONSTRAINT `menu_item_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`);

--
-- Constraints for table `restaurantadmin`
--
ALTER TABLE `restaurantadmin`
  ADD CONSTRAINT `restaurantadmin_ibfk_1` FOREIGN KEY (`restaurantID`) REFERENCES `restaurant` (`restaurantID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
