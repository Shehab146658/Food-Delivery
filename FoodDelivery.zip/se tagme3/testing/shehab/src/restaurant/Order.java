/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.util.ArrayList;

/**
 *
 * @author shehab146658
 */
public class Order implements Observable {
    public int orderId;
    public String customerID;
    private String status;
    
    private ArrayList<Observer> restaurant=new ArrayList<Observer>();
    
    private ArrayList<Observer> allRestaurants=new ArrayList<Observer>();
    
    private ArrayList<Observer> restaurantAdmin=new ArrayList<Observer>();

    public Order(int orderId, String customerID, String status) {
        this.orderId = orderId;
        this.customerID = customerID;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    
    
   
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public void addOrder(Customer c)
    {
        notifyObserver();
    }
    
    public void removeOrder(Customer c)
    {
        notifyObserver();
    }
    
    
    
    @Override
    public void addObserver(Observer o)
    {
        restaurant.add(o);
    }
    
    @Override
    public void removeObserver(Observer o)
    {
        int observerIndex=restaurant.indexOf(o);
        System.out.println("Restaurant"+(observerIndex+1)+"deleted");
        restaurant.remove(o);
    }
    
    @Override
    public void notifyObserver()
    {
        //notify all intersted
        for(Observer Restaurants:restaurant )
        {
            Restaurants.update();
        }
    }
    
}
