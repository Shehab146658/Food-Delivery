/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author shebo
 */
public class orderDB {
    private final String userName = "root";
    private final String password = "";
    private final String dbName = "restaurant";

    private Connection con;
    
    public orderDB() {
        try {
            
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }

    
    public boolean addOrder(Order o) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into restaurant values ('"+o.getOrderId() + "', '"+o.customerID+ "', '"+o.getStatus() +"'");
            System.out.println("Order added successfuly");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
        return false;
    }
    
    public boolean deleteOrder(int id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from order where orderId = "+ id + "");
            System.out.println("Order deleted successfuly");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
            return false;
        }
    }
    
    public ArrayList<Order> getAllOrders() {
        ArrayList<Order> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `order` ");
            while (rs.next()) {
                result.add(new Order(rs.getInt("orderId"),rs.getString("customerID"),rs.getString("status")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
