/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import restaurant.Restaurant;
import restaurant.restaurantDB;
import static org.junit.Assert.assertEquals;

/**
 *
 * @author shebo
 */
public class JUnitTestingRestaurant {
    
    @Test
    public void testAddRestaurant() {
        Restaurant r=new Restaurant(20,"arabiata","rehab","0100100","19999");
        
        restaurantDB c = new restaurantDB();
        
        boolean result = c.addRestaurant(r);
        assertEquals(true, result);
        
    }
    
    @Test
    public void testDeleteRestaurant() {
        restaurantDB c = new restaurantDB();
        boolean result = c.deleteRestaurant("arabiata");
        assertEquals(true, result);
    }
    
    
}
