package test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fatma
 */

import org.junit.Test;
import restaurant.SystemAdmin;
import restaurant.AdminDB;
import static org.junit.Assert.assertEquals;
public class JUnitTestingAdmin {
     @Test
    public void testAddAdmin() {
   
        SystemAdmin s=new SystemAdmin("2","fatma","elzahraa","mekhemer","nasrCity","5084984058","44084042942","fatma","fatma12345"); 
        AdminDB c = new AdminDB();
        
        boolean result=  c.addAdmin(s);
        assertEquals(true,result  );
    }
    
    @Test
    public void testDeleteAdmin() {
        AdminDB c = new AdminDB();
        
        boolean result = c.deleteAdmin("2");
        assertEquals(true, result);
    }
     @Test
    public void testUpdateAdmin(){
        AdminDB c=new AdminDB();
        boolean result=c.updateAdmin("2","tagmou","medhat","ehab","ahmed","5084984058","44084042942","medhat","medhat12345");
       assertEquals(true, result);
    }
    
    
}
