/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import restaurant.Restaurant;
import restaurant.customer;
import restaurant.customerdb;
import restaurant.restaurantDB;

/**
 *
 * @author shebo
 */
public class JUnitTestingCustomer {
     @Test
    public void testAddCustomer() {
        customer c =new customer("shehabb", "shehab", "shehab", "011144253", "2125", "nasr city", "shehab", "shehab");
        customerdb cb = new customerdb();
        
        boolean result = cb.addcustomer(c);
        assertEquals(true, result);
        
    }
    public void testDeleteCustomer() {
        customerdb cb = new customerdb();
        
        boolean result = cb.deletecustomer("2");
        assertEquals(true, result);
        
    }
    
}
