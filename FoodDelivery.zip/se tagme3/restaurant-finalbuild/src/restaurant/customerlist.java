/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
/**
 *
 * @author Shehab
 */
public class customerlist {
    
    JFrame f;    
    customerlist(){    
    f=new JFrame();    
    /*
    String data[][]={ {"101","Amit","670000","lala","land","samah","samoha"},    
                          {"102","Jai","780000","lala","land","samah","samoha"},    
                          {"101","Sachin","700000","lala","land","samah","samoha"}};  
*/
    String id,firstname,midname,lastname,phoneno,homeno,address;
    
    customerdb db = new customerdb();
       // System.out.println(username);
        //System.out.println(password);
        ArrayList<customer> c = new ArrayList();
        c = db.getAllcustomers();
        String[][] data  = new String[50][7];
        for(int i=0;i<c.size();i++){
        data[i][0] = c.get(i).getid();
        data[i][1] = c.get(i).getFirstName();
        data[i][2] = c.get(i).getMidName();
        data[i][3] = c.get(i).getLastName();
        data[i][4] = c.get(i).getPhoneNumber();
        data[i][5] = c.get(i).getHomeNumber();
        data[i][6] = c.get(i).getAddress();
        }
        
        
   String column[]={"ID","firstname","midname","lastname","phone no","home no","address"};         
    // String column[]={"ID","NAME","SALARY"};     
    JTable jt=new JTable(data,column);    
    jt.setBounds(50,50,800,600);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(800,600);    
    f.setVisible(true);    
}

public static void main(String[] args) {    
    new customerlist();    
     
}    
}  
