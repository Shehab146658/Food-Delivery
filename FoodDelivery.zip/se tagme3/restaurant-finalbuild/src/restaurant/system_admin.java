/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.personT;

/**
 *
 * @author Rawan
 */
public class system_admin extends personT {
    
  private int adminId;

    public system_admin(String Adress, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password, int id) {
       // super(Adress, firstName, homeNumber, lastName, midName, phoneNumber, username, password, id);
       super(Adress, firstName, homeNumber, lastName, midName, phoneNumber, username, password);
    }

    

    
    
   public  void viewrecentorders(){}
   public  void monitororders(){}
   public  void viewallpendingorders(){}
   public  void confirmorders(){}
   public  void cancelorder(){}
   public  void updateresturantinfo(){}
   public  void addresturant(){}
   public void  deleteresturant(){}
   public void viewcomments(){}
    
}
