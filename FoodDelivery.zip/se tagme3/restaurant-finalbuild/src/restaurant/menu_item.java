/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.menu_component;

/**
 *
 * @author Rawan
 */
public class menu_item extends menu_component {
   
    private String item_id;
    private String menu_id;
    private String name;
    private String type;
    private String description;
    private String price;

    public menu_item(String item_id, String menu_id, String name, String type, String description, String price) {
        this.item_id = item_id;
        this.menu_id = menu_id;
        this.name = name;
        this.type = type;
        this.description = description;
        this.price = price;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(String menu_id) {
        this.menu_id = menu_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

   
    public void display(){}
    
    
}
