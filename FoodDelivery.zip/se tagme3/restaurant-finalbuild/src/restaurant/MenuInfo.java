/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
import restaurant.MenuItemDatabase;
import restaurant.MenuItemDatabase;
import restaurant.menu_item;
import restaurant.menu_item;
public class MenuInfo {
    JFrame f;    
    MenuInfo(){    
    f=new JFrame();
//    String adminid,address,firstname,midname,lastname,homenumber,phonenumber;
    
    
       // System.out.println(username);
        //System.out.println(password);
      
         MenuItemDatabase  db=new MenuItemDatabase(); 
            ArrayList<menu_item> s = new ArrayList();
        s= db.getallmenuitems();
        String[][] data  = new String[50][9];
        for(int i=0;i<s.size();i++){
        data[i][0] = s.get(i).getItem_id();
        data[i][1] = s.get(i).getMenu_id();
        data[i][2] = s.get(i).getName();
        data[i][3] = s.get(i).getType();
        data[i][4] = s.get(i).getDescription();
        data[i][5] = s.get(i).getPrice();
        
       
        }
            
 
    String column[]={"item_id","menu_id","name","type","description","price"};         
   
   JTable jt=new JTable(data,column); 
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(300,400);    
    f.setVisible(true);    
}     
public static void main(String[] args) {    
    new MenuInfo();  
    
    
    //System.out.println("retrived: "+db.getTheCurrentAdmins());
}    
}
