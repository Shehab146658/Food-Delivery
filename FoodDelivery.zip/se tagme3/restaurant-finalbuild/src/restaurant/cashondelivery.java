/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
public class cashondelivery implements paymentmethod{
    private float amount;
    private String customerid;
    private boolean ispaid=false;
    
    public boolean check(){
    return true;
    }
    public void pay(){
        if(this.check()==true){
        ispaid = true;
        }
    }

    public cashondelivery() {
    }

    public cashondelivery(float amount, String customerid) {
        this.amount = amount;
        this.customerid = customerid;
       
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

  

   

    public int isIspaid() {
       if(ispaid==true)
            return 1;
        else return 0;
    }

    public void setIspaid(boolean ispaid) {
        this.ispaid = ispaid;
    }
    
    
}
