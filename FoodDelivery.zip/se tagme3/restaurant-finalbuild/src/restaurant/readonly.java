/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.util.ArrayList;
import restaurant.customer;
import restaurant.SystemAdmin;
import restaurant.restaurantAdmin;

/**
 *
 * @author fatma
 */
public class readonly {
  private static readonly system;  
  ArrayList<customer> customerList= new ArrayList<customer>();
  ArrayList<SystemAdmin> adminList= new ArrayList<SystemAdmin>();
  ArrayList<restaurantAdmin> restaurantadminList= new ArrayList<restaurantAdmin>();
 private readonly()
 {
     this.system=system;
 }
 
public void addCustomer(customer customer)
{

}
public void deleteCustomer(customer customer)
{

}
public void modifyCustomer(customer customer)
{
    
}
public void addAdmin(SystemAdmin admin)
{
    
}
public void modifyAdmin(SystemAdmin admin)
{
    
}
public void deleteAdmin(SystemAdmin admin)
{
    
}
public void addRestaurant()
{
    
}
public void updateRestaurant()
{
    
}
public void deleteRestaurant()
{
    
}
public void viewRestaurant()
{
    
}
 public void viewAllAdministrators()
     {
         
     }
     public void viewAllCustomers()
     {
         
     }
     public void viewCustomerInfo()
     {
         
     }
     
 public static readonly readonly()
  {
      if(system==null)
      {
          system=new readonly();
      }
      return system;
  }
}
