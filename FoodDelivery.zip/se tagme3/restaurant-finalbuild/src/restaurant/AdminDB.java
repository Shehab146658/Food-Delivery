/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

   
public class AdminDB {
      private final String username = "root";
    private final String password = "";
    private final String databaseName = "restaurant";
    private Connection conn;
      public AdminDB()
    {
        try{
        Class.forName("com.mysql.jdbc.Driver").newInstance(); 
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseName, username, password);
        }catch(Exception e){
             System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
         
    }
       public boolean addAdmin(SystemAdmin admin)
    {
    try {
            Statement stmt = conn.createStatement();
                   stmt.executeUpdate("insert into system_admin values('" + admin.getAdmin_id() + "', '" + admin.getFirst_name()+"', '"+admin.getMid_name()+"', '"+admin.getLast_name()+"', '"+admin.getAdress()+"', '"+admin.getHome_number()+"', '"+admin.getPhone_number()+"', '"+admin.getUsername()+"', '"+admin.getPassword()+"')");

            System.out.println("Admin added successfully");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
            return false;
        }
    }
    public boolean deleteAdmin(String admin_id)
    {
         try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("delete from system_admin where admin_id = '" + admin_id+ "'");
            System.out.println("Admin deleted successfully");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
            return false;
        }
    }
       public boolean updateAdmin(String admin_id,String Address,String firstName,String midName,String lastName,String homeNumber,String phoneNumber,String username,String password)
    {
         try {
            Statement stmt = conn.createStatement();
             stmt.executeUpdate("update system_admin set adress='" +Address + "', first_name= '" + firstName+"', mid_name= '"+midName+"', last_name='"+lastName+"', home_number='"+homeNumber+"', phone_number= '"+phoneNumber+"', username= '"+username+"', password= '"+password+"'where admin_id= '"+admin_id+"'");
            System.out.println("Admin updated succesfully");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
            return false;
        }
    }
        public ArrayList<SystemAdmin> getTheCurrentAdmins() {
        ArrayList<SystemAdmin> result = new ArrayList();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from system_admin");
            while (rs.next()) {
                result.add(new SystemAdmin(rs.getString("admin_id"),rs.getString("adress"),rs.getString("first_name"),rs.getString("mid_name"),rs.getString("last_name"),rs.getString("home_number"),rs.getString("phone_number"),rs.getString("username"), rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
