/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.OffersAndPromoCodes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Rawan
 */
public class systemadmin_database {
    
    private final String username = "root";
    private final String password = "";
    private final String database = "resturant";
    
    private Connection con;
    
    
    public systemadmin_database() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + database, username, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
   public void addpromocode(OffersAndPromoCodes promo) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into offers values('" + promo.getCodeId() + "', '" +promo.getResturantId()+ "', '" +promo.getPoductionDate()+ "', '" +promo.getDescription()+ "', '" +promo.getValue()+"')");
            System.out.println("promo code  added");
        } catch (Exception e) {
            System.err.println("CANNOT ADD THE PROMOCODE: " + e.toString());
        }
    }
   
   public void deletepromo(String codeId) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from offers where offer_id='"+codeId+"'" );
            System.out.println("Promocode deleted");
        } catch (Exception e) {
            System.err.println("CANNOT DELELETE THE PROMO CODE: " + e.toString());
        }
    }
     public void updatePrmocode(String codeId,String resturantId,String  poductionDate,String description,String value) {
        try {
            Statement stmt = con.createStatement();
             stmt.executeUpdate("update offers set offer_id = '" + codeId +"', production_date= '"+poductionDate+"', description='"+description+"', value='"+value+ "'where resturant_id= '"+resturantId+ "'");
            System.out.println("Promo Code updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    public OffersAndPromoCodes getpromocodebyid(String prmocode) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from offers where offer_id = '" + prmocode + "'");
            if (rs.first()) {
                return new OffersAndPromoCodes(rs.getString("offer_id"),rs.getString("resturant_id"),rs.getString("production_date"),rs.getString("description"),rs.getString("value"));
            }
        } catch (Exception e) {
            System.err.println(" ERROR: " + e.toString());
        }
        return null;
    }
    
public ArrayList<OffersAndPromoCodes> getallcodes() {
        ArrayList<OffersAndPromoCodes> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from offers");
            while (rs.next()) {
                result.add(new OffersAndPromoCodes(rs.getString("offer_id"),rs.getString("resturant_id"),rs.getString("production_date"),rs.getString("description"),rs.getString("value")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
