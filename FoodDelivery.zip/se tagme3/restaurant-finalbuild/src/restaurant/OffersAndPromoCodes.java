/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Rawan
 */
public class OffersAndPromoCodes {
    private String codeId;
    private String resturantId;
    private String  poductionDate;
    private String description;
    private String value ;

    public OffersAndPromoCodes(String codeId, String resturantId, String poductionDate, String description, String value) {
        this.codeId = codeId;
        this.resturantId = resturantId;
        this.poductionDate = poductionDate;
        this.description = description;
        this.value = value;
    }

    public String getCodeId() {
        return codeId;
    }

    public void setCodeId(String codeId) {
        this.codeId = codeId;
    }

    public String getResturantId() {
        return resturantId;
    }

    public void setResturantId(String resturantId) {
        this.resturantId = resturantId;
    }

    public String getPoductionDate() {
        return poductionDate;
    }

    public void setPoductionDate(String poductionDate) {
        this.poductionDate = poductionDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    
}
