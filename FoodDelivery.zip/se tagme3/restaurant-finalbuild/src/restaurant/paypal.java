/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
public class paypal implements paymentmethod {
    private String customerid;
    private String accountnumber;
    private float balance;
    private boolean ispaid=false;
     /*
    public boolean check(){
    if(balance>=value){
    return true;
    }
    else{
        return false;
            }
    }
    public void pay(){
        if (this.check()==true){
    balance = balance - value;
    ispaid=true;
        }
        else{
        
        }
    }
*/
    public paypal(String customerid, String accountnumber, float balance) {
        this.customerid = customerid;
        this.accountnumber = accountnumber;
        this.balance = balance;
    }

    public paypal() {
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

   

    public String getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }

   

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public int isIspaid() {
        if(ispaid==true)
            return 1;
        else return 0;
    }

    public void setIspaid(boolean ispaid) {
        this.ispaid = ispaid;
    }
    
}
