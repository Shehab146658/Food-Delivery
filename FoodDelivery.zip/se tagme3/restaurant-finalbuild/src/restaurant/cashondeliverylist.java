/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*; 
/**
 *
 * @author Shehab
 */
public class cashondeliverylist {
        JFrame f;   
        public  cashondeliverylist(){
         f=new JFrame();  
        String amount,customerid;
        paymentmethoddb db = new paymentmethoddb();
        ArrayList<cashondelivery>p = new ArrayList();
        p = db.getcashondeliverytrans();
         String[][] data  = new String[50][2];
         for(int i=0;i<p.size();i++){
         data[i][1] =Float.toString(p.get(i).getAmount());
         data[i][0] =p.get(i).getCustomerid();
         }
         String column[] ={"customer id","amount"};
           JTable jt=new JTable(data,column);    
    jt.setBounds(50,50,800,600);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(800,600);    
    f.setVisible(true);   
         
         
        }
         public static void main(String[] args) {    
    new cashondeliverylist();    
     
}    
        
        
}
