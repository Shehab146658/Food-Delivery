/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
/**
 *
 * @author Shehab
 */
public class shoppingcartlist {
      JFrame f;    
    shoppingcartlist(){  
        f=new JFrame();
        String cartid,customerid,itemid,notes,quantity;
        shoppingcartdb db = new shoppingcartdb();
        ArrayList<shoppingcart> sc = new ArrayList();
        sc = db.getallshoppingcarts();
        String [][] data = new String [50][5];
        for(int i=0;i<sc.size();i++){
        data[i][0]= sc.get(i).getCartid();
        data[i][1]= sc.get(i).getCustomerid();
        data[i][2]=sc.get(i).getItemid();
        data[i][3]=sc.get(i).getNotes();
        data[i][4]=Integer.toString(sc.get(i).getQuantity());
        }
        String column[]= {"cart id","customer id","item id","notes","quantity"};
        JTable jt=new JTable(data,column);    
    jt.setBounds(50,50,800,600);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(800,600);    
    f.setVisible(true);    
    }  
     public static void main(String[] args) {    
    new shoppingcartlist();    
     
}   
}
