/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
/**
 *
 * @author Shehab
 */
public class paypallist {
    JFrame f;   

    public paypallist() {
         f=new JFrame();    
        String customerid,accountnumber,balance;
        paymentmethoddb db = new paymentmethoddb();
        ArrayList<paypal>p = new ArrayList();
        p = db.getpaypaltrans();
        String[][] data  = new String[50][7];
        
        for(int i=0;i<p.size();i++){
        data[i][0]=p.get(i).getCustomerid();
        data[i][1]=p.get(i).getAccountnumber();
        data[i][2]=Float.toString(p.get(i).getBalance());
        }

       
        String column[] = {"customer id","account number","balance"};
         JTable jt=new JTable(data,column);    
    jt.setBounds(50,50,800,600);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(800,600);    
    f.setVisible(true);   
        
    }
    
    public static void main(String[] args) {    
    new paypallist();    
     
}    
}
