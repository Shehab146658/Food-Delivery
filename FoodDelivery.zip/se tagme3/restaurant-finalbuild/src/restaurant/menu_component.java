/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.menu_item;

/**
 *
 * @author Rawan
 */
public abstract class menu_component {
    public void AddMenuItem(menu_item item){}
    public void RemoveMenuItem(menu_item item){}
    public menu_component getchild(int com){return null;}
    public String getname(){return null;}
    public String getdescription(){return null;}
    public String gettype(){return null;}
    public float getprice(){return 0;}
    public void desplay(){}

    
}
