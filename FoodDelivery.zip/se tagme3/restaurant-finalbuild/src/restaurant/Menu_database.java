/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Rawan
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurant.menu;

public class Menu_database {
    private final String username = "root";
    private final String password = "";
    private final String database = "resturant";
    
    private Connection con;
    
    public Menu_database() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + database, username, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
          
    }
    
    public void addmenu(menu m) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into menu values('" + m.getMenu_id() + "', '" +m.getResturant_id()+ "', '" +m.getDate_update()+"')");
            System.out.println("new menu is added");
        } catch (Exception e) {
            System.err.println("CANNOT ADD THE MENU: " + e.toString());
        }
    }
    
    public void deletemenu(String menu_id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from menu where menu_id ='"+ menu_id + "'");
            System.out.println("new menu is delete");
        } catch (Exception e) {
            System.err.println("CANNOT ADD THE MENU: " + e.toString());
        }
    }
    
    public void updatemenu(String menu_id , String resturantid,String Date_update) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update menu set menu_id = '" + menu_id+"',date_update='"+Date_update + "'where resturant_id= '"+resturantid+ "'");
            System.out.println(" Menu is updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    public menu getpromocodebyid(String menuid) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from menu where menu_id = '" + menuid + "'");
            if (rs.first()) {
                return new menu(rs.getString("menu_id"),rs.getString("resturant_id"),rs.getString("date_update"));
            }
        } catch (Exception e) {
            System.err.println(" ERROR: " + e.toString());
        }
        return null;
    }
    
    public ArrayList<menu> getallmenus() {
        ArrayList<menu> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from menu");
            while (rs.next()) {
                result.add(new menu(rs.getString("menu_id"),rs.getString("resturant_id"),rs.getString("date_update")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
