/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.util.ArrayList;

/**
 *
 * @author Shehab
 */
public class customer extends personT{
    private String customerid;
    
    ArrayList<userreviews> reviews = new ArrayList();
    ArrayList<orders> orders = new ArrayList();

    public customer(String firstName, String midName, String lastName, String phoneNumber, String homeNumber, String Address, String username, String password) {
        super(Address, firstName, homeNumber, lastName, midName, phoneNumber, username, password);
        customerid = super.setid('a');
    }
    
    public void editinfo(String Address, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password){
   super.setAddress(Address);
   super.setFirstName(firstName);
   super.setHomeNumber(homeNumber);
   super.setLastName(lastName);
   super.setMidName(midName);
   super.setPhoneNumber(phoneNumber);
   super.setUsername(username);
   super.setPassword(password);
    
    }
    
   
    
            
}
