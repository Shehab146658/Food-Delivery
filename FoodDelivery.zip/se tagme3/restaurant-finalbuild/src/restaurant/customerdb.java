/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class customerdb {
    private Connection con;
        private final String userName = "root";
        private final String password = "";
        private final String dbName = "restaurant";
        
        public customerdb() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
         public boolean addcustomer(customer c) {
        try {
            
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into customerlogin values ('"+c.getid() + "', '"+c.getUsername() + "', '"+c.getPassword() +"')");
            stmt.executeUpdate("insert into customer values('" + c.getid() + "', '" + c.getFirstName()+ "', '" +c.getMidName()+ "', '" +c.getLastName()+ "', '" +c.getPhoneNumber()+ "', '" +c.getHomeNumber()+ "', '" +c.getAddress()+ "', '" +c.getUsername()+ "', '" +c.getPassword() + "')");
            System.out.println("customer added");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
            return false;
        }
    }
         
         public boolean deletecustomer(String id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from customerlogin where customerid = '" + id + "'");
            stmt.executeUpdate("delete from customer where id = '" + id + "'");
            //stmt.executeUpdate("delete from ")
            System.out.println("customer deleted");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
            return false;
        }
    }
         public void updatecustomerusername(String id, String newuser) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update customerlogin set username = '" + newuser + "' where customerid = '" + id + "'");
            stmt.executeUpdate("update customer set username = '" + newuser + "' where id = '" + id + "'");
            System.out.println("customer updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
         
         public void updatecustomerpassword(String id, String newpass) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update customerlogin set password = '" + newpass + "' where customerid = '" + id + "'");
            stmt.executeUpdate("update customer set password = '" + newpass + "' where id = '" + id + "'");
            System.out.println("customer updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
         
         public void updatecustomerinfo(String firstname, String midname,String lastname,String phoneno,String homeno,String address,String id) {
        try {
            Statement stmt = con.createStatement();
            
            stmt.executeUpdate("update customer set firstname = '" + firstname +"',midname='"+midname+"',lastname='"+lastname+"',phonenumber='"+phoneno+"',homenumber='"+homeno+"',address='"+address +"' where id = '" + id + "'");
            System.out.println("customer updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
         
         public customer getcustomerbyid(String id) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from customer where id = '" + id + "'");
            if (rs.first()) {
                return new customer(rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("phonenumber"),rs.getString("homenumber"),rs.getString("address"),rs.getString("username"),rs.getString("password"));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return null;
    }
         
          public ArrayList<customer> getAllcustomers() {
        ArrayList<customer> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from customer");
            while (rs.next()) {
                result.add(new customer(rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("phonenumber"),rs.getString("homenumber"),rs.getString("address"),rs.getString("username"),rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
        
}
