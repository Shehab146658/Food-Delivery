/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*; 
/**
 *
 * @author Shehab
 */
public class creditcardlist {
        JFrame f;   
        public creditcardlist(){
         f=new JFrame();    
        String customerid,creditcardno,balance;
        paymentmethoddb db = new paymentmethoddb();
        ArrayList<creditcard>c = new ArrayList();
        c = db.getcreditcardtrans();
        String[][] data  = new String[50][7];
        for(int i=0;i<c.size();i++){
        data[i][0]= c.get(i).getCustomerid();
        data[i][1]= c.get(i).getCreditcardno();
        data[i][2]=Float.toString(c.get(i).getBalance());
        }
        
         String column[] = {"customer id","credit card no","balance"};
        JTable jt=new JTable(data,column);    
    jt.setBounds(50,50,800,600);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(800,600);    
    f.setVisible(true); 
        }
        
         public static void main(String[] args) {    
    new creditcardlist();    
     
}    
}
