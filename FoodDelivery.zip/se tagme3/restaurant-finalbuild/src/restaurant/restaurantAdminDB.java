/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author shebo
 */
public class restaurantAdminDB {
    
    private final String username = "root";
    private final String password = "";
    private final String databaseName = "restaurant";
    
    private Connection conn;
    
    
    
     public restaurantAdminDB()
    {
        try{
        Class.forName("com.mysql.jdbc.Driver").newInstance(); 
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseName, username, password);
        }catch(Exception e){
             System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
     
    public void addAdmin(restaurantAdmin admin)
    {
        try 
        {
            Statement stmt = conn.createStatement();
            
            stmt.executeUpdate("insert into restaurant values ('"+admin.getRestaurantID() + "', '"+"')");
            stmt.executeUpdate("insert into restaurantadmin values ('"+admin.getManagerID() + '"'+admin.getRestaurantID()+ "','"+admin.getFirstName()+"','"+admin.getMidName()+"','"+admin.getLastName()+"','"+admin.getAddress()+"','"+admin.getHomeNumber()+"','"+admin.getPhoneNumber()+"','"+admin.getUsername()+"','"+admin.getPassword()+"')");
            System.out.println("Admin added sucessfully");
        } 
        catch (Exception e) 
        {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    public void deleteAdmin(String admin_id)
    {
         try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("delete from restaurantadmin where managerID = '" + admin_id+ "'");
            System.out.println("Restaurant Admin deleted successfully");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
    
    
    public ArrayList<restaurantAdmin> getAllRestaurantAdmins() {
        ArrayList<restaurantAdmin> result = new ArrayList();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from restaurantadmin");
            while (rs.next()) {
                result.add(new restaurantAdmin(rs.getString("managerID"),rs.getString("restaurantID"),rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("address"),rs.getString("phoneNo"),rs.getString("homeNo"),rs.getString("username"),rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
