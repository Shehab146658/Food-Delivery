/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author shebo
 */

public class restaurantDB {
    private final String userName = "root";
    private final String password = "";
    private final String dbName = "restaurant";

    private Connection con;

    public restaurantDB() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }

    public boolean addRestaurant(Restaurant r) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into restaurant values ('"+r.getRestaurantId() + "', '"+r.getName()+ "', '"+r.getPhoneNo() +"','"+r.getHotline()+"','"+r.getAddress()+"')");
            System.out.println("Restaurant added sucessfully");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: Code Already Exists");
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
        return false;
    }
    
    public boolean deleteRestaurant(String name) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from restaurant where name = '" + name + "'");
            System.out.println("Restaurant deleted");
            return true;
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
            return false;
        }
    }

    public void updateHotline(String name, String hotlin) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update restaurant set hotline = '" + hotlin + "' where name = '" + name + "'");
            System.out.println("Restaurant Hotline updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    
    public void updateName(String name, String rname) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update restaurant set name = '" + rname + "' where name = '" + name + "'");
            
            System.out.println("Restaurant Name updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    public void updatephoneNo(String name, String phoneNo) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update restaurant set phoneNo = '" + phoneNo + "' where name = '" + name + "'");
            System.out.println("Restaurant phone number updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    public void updateaddress(String name, String address) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update restaurant set address = '" + address + "' where name = '" + name + "'");
            System.out.println("Restaurant address updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }

    public Restaurant getRestaurantByName(String name) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from restaurant where name = '" + name + "'");
            if (rs.first()) {
                return new Restaurant(rs.getInt("restaurantID"),rs.getString("name"),rs.getString("address"), rs.getString("phoneNo"),rs.getString("hotline"));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return null;
    }
    

    public ArrayList<Restaurant> getAllRestaurants() {
        ArrayList<Restaurant> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from restaurant");
            while (rs.next()) {
                result.add(new Restaurant(rs.getInt("restaurantID"),rs.getString("name"),rs.getString("address"), rs.getString("phoneNo"),rs.getString("hotline")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
