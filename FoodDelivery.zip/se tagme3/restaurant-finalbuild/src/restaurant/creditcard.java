/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
public class creditcard implements paymentmethod {
   private String creditcardno;
   private String customerid;
    private float balance;
    private boolean ispaid=false;
    public String getCreditcardno() {
        return creditcardno;
    }
/*
   public boolean check(){
    if(balance>=value){
    return true;
    }
    else{
        return false;
            }
    }
   */
    /*
    public void pay(){
        if (this.check()==true){
    balance = balance - value;
    ispaid=true;
        }
        else{
        
        }
    }
    */
    public creditcard(String creditcardno, String customerid, float balance) {
        this.creditcardno = creditcardno;
        this.customerid = customerid;
        this.balance = balance;
    }

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    
   

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public int isIspaid() {
        if(ispaid==true)
            return 1;
        else return 0;
    }

    public void setIspaid(boolean ispaid) {
        this.ispaid = ispaid;
    }

    public creditcard() {
    }
    
    
}

