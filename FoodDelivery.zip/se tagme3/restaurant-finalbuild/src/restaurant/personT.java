/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.util.Random;

/**
 *
 * @author Shehab
 */
public abstract class personT {
    private String id;
    private String Address;
    private String firstName;
    private String homeNumber;
    private static Integer indexofcustomer=0;
    private static Integer indexofsysmadmin=0;
    private static Integer indexofrestadmin=0;
    private String lastName;
    private String midName;
    private String phoneNumber;
    private String username;
    private String password;
    
    public personT(String Address, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password) {
        this.Address = Address;
        this.firstName = firstName;
        this.homeNumber = homeNumber;
        
        this.lastName = lastName;
        this.midName = midName;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
        
         Random r = new Random();
int Low = 3;
int High = 100;
int Result = r.nextInt(High-Low) + Low;
indexofcustomer =Result;
 ////customerdb db = new customerdb();
    // indexofcustomer =  db.getAllcustomers().size();
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }
    
    public String getAddress(){
        return Address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getHomeNumber() {
        return homeNumber;
    }

    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    public String setid(char state) {
       
        String temp="";
        switch(state){
            case 'a':
                indexofcustomer++;
                temp="A"+indexofcustomer.toString();
                this.id = temp;
                return(temp);
            case 'b':
                indexofsysmadmin++;
                temp="B"+indexofsysmadmin.toString();
                this.id = temp;
                return(temp);
            case 'c':
                indexofrestadmin++;
                temp="C"+indexofrestadmin.toString();
                this.id = temp;
                return(temp);
                   
            default: 
                temp="0";
                this.id = temp;
                break;
        }
        return temp;
    }

    public String getid(){
        return id;
    }
    

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMidName() {
        return midName;
    }

    public void setMidName(String midName) {
        this.midName = midName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
