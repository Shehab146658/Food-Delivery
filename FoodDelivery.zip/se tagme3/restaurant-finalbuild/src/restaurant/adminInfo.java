/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
public class adminInfo {    
    JFrame f;    
    adminInfo(){    
    f=new JFrame();
 String adminid,address,firstname,midname,lastname,homenumber,phonenumber;
    
    
       // System.out.println(username);
        //System.out.println(password);
      
          AdminDB db=new AdminDB(); 
            ArrayList<SystemAdmin> s = new ArrayList();
        s= db.getTheCurrentAdmins();
        String[][] data  = new String[50][9];
        for(int i=0;i<s.size();i++){
        data[i][0] = s.get(i).getAdmin_id();
        data[i][1] = s.get(i).getAdress();
        data[i][2] = s.get(i).getFirst_name();
        data[i][3] = s.get(i).getMid_name();
        data[i][4] = s.get(i).getLast_name();
        data[i][5] = s.get(i).getHome_number();
        data[i][6] = s.get(i).getPhone_number();
        data[i][7]=s.get(i).getUsername();
        data[i][8]=s.get(i).getPassword();
        }
            
 
    String column[]={"admin id","address","first name","mid name","last name","home number","phone number","username","password"};         
   
   JTable jt=new JTable(data,column); 
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(300,400);    
    f.setVisible(true);    
}     
public static void main(String[] args) {    
    new adminInfo();  
    AdminDB db=new AdminDB();
    
    //System.out.println("retrived: "+db.getTheCurrentAdmins());
}    
}  
