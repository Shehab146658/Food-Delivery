/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurant.SystemManager;
import restaurant.SystemManager;
public class ManagerDB {
    private final String username = "root";
    private final String password = "";
    private final String databaseName = "restaurant";
    
    private Connection conn;
    public ManagerDB()
    {
         try{
        Class.forName("com.mysql.jdbc.Driver").newInstance(); 
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + databaseName, username, password);
        }catch(Exception e){
             System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
      public void updateManager(String manager_id,String Address,String firstName,String midName,String lastName,String homeNumber,String phoneNumber,String username,String password)
    {
         try {
            Statement stmt = conn.createStatement();
               stmt.executeUpdate("update managerlogin set username = '" + username + "', password= '" + password+ "' where manager_id = '" + manager_id + "'");
             stmt.executeUpdate("update systemmanager set Address='" +Address + "', firstName= '" + firstName+"', midName= '"+midName+"', lastName='"+lastName+"', homeNumber='"+homeNumber+"', phoneNumber= '"+phoneNumber+"', username= '"+username+"', password= '"+password+"'where manager_id= '"+manager_id+"'");
            System.out.println("Manager updated succesfully");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
     public SystemManager getManagerByName(String username) {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from systemmanager where username = '" + username + "'");
            if (rs.first()) {
                return new SystemManager(rs.getString("manager_id"),rs.getString("Address"),rs.getString("firstName"),rs.getString("homeNumber"),rs.getString("lastName"),rs.getString("midName"),rs.getString("phoneNumber"),rs.getString("username"), rs.getString("password"));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return null;
    }

    public ArrayList<SystemManager> getTheCurrentManager() {
        ArrayList<SystemManager> result = new ArrayList();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from systemmanager");
            while (rs.next()) {
                result.add(new SystemManager(rs.getString("manager_id"),rs.getString("Address"),rs.getString("firstName"),rs.getString("midName"),rs.getString("lastName"),rs.getString("homeNumber"),rs.getString("phoneNumber"),rs.getString("username"), rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }

}
