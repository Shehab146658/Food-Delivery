/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.Observable;
import restaurant.Observer;

/**
 *
 * @author shehab146658
 */
public class Restaurant implements Observer {
    private String name;
    private String address;
    private String phoneNo;
    private String hotline;
    private int restaurantId;
    private Observable observable=null;
    
    
    
    public Restaurant(int rest,String name, String address, String phoneNo, String hotline) {
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.hotline = hotline;
        this.restaurantId = rest;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getHotline() {
        return hotline;
    }

    public void setHotline(String hotline) {
        this.hotline = hotline;
    }
    
    public void setRestaurantId(int restaurantID) {
        this.restaurantId=restaurantID;
    }
    public int getRestaurantId() {
        return restaurantId;
    }


    public void viewOrders()
    {
        
    }
    
    public void updateResaurantHotline(String name,String hotline)
    {
        restaurantDB r=new restaurantDB();
        r.updateHotline(name, hotline);
    }
    
    
    
    public void viewRestaurantInfo(String name)
    {
        restaurantDB r=new restaurantDB();
        r.getRestaurantByName(name);
    }
    
    @Override
    public void update()
    {
        orderStatus();
        unsubscribe();
    }
    
    public void orderStatus()
    {
        System.out.println("anything");
    }
    
    public void unsubscribe()
    {
        observable.removeObserver(this);
    }
    
}
