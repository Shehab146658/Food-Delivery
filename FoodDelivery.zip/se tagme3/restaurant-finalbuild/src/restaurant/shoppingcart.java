/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
public class shoppingcart {
    private static Integer cartcount=0;
    private String cartid;
    private String customerid;
    private String itemid;
    private String notes;
    private int quantity;
    public shoppingcart() {
    }

    public shoppingcart(String customerid, String itemid, String notes,int quantity) {
        //Integer temp = cartcount++;
        cartid = "sc"+customerid;
        this.customerid = customerid;
        this.itemid = itemid;
        this.notes = notes;
        this.quantity = quantity;
    }
    /*
    public shoppingcart(String customerid, String itemid, String notes,int quantity,int id) {
        //Integer temp = cartcount++;
        Integer temp = id;
        cartid = temp.toString();
        this.customerid = customerid;
        this.itemid = itemid;
        this.notes = notes;
        this.quantity = quantity;
    }
*/
    public static int getCartcount() {
        return cartcount;
    }

    public static void setCartcount(int cartcount) {
        shoppingcart.cartcount = cartcount;
    }

    public String getCartid() {
        return cartid;
    }

    

    public String getCustomerid() {
        return customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
    
    
}
