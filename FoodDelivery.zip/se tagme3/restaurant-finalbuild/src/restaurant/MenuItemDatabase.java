/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Rawan
 * 
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import restaurant.menu_item;
import restaurant.menu_item;


public class MenuItemDatabase {
    
    private final String username = "root";
    private final String password = "";
    private final String database = "resturant";
    
    private Connection con;
    
    public MenuItemDatabase() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + database, username, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
    public void addmenuitem(menu_item men) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into menu_item values('" + men.getItem_id() + "', '" +men.getMenu_id()+ "', '" +men.getName()+ "', '" +men.getName()+ "', '" +men.getType()+ "', '" +men.getdescription()+ "', '" +men.getPrice()+"')");
            System.out.println("new item is added");
        } catch (Exception e) {
            System.err.println("CANNOT ADD THE ITEM ON THE MENU: " + e.toString());
        }
    }
    
    public void deletemenuitem(String menu_id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from menu_id where = '"+menu_id+"'");
            System.out.println("new item is added");
        } catch (Exception e) {
            System.err.println("CANNOT ADD THE ITEM ON THE MENU: " + e.toString());
        }
    }
    public void updateitem(String item_id,String menu_id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update menu_item set item_id = '" + item_id + "where menu_id= '"+menu_id+ "'");
            System.out.println(" Menu is updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
    public menu_item getpromocodebyid(String itemid) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from menu_item where item_id = '" + itemid + "'");
            if (rs.first()) {
                return new menu_item(rs.getString("item_id"),rs.getString("menu_id"),rs.getString("name"),rs.getString("type"),rs.getString("description"),rs.getString("price"));
            }
        } catch (Exception e) {
            System.err.println(" ERROR: " + e.toString());
        }
        return null;
    }
    public ArrayList<menu_item> getallmenuitems() {
        ArrayList<menu_item> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from menu_items");
            while (rs.next()) {
                result.add(new menu_item(rs.getString("item_id"),rs.getString("menu_id"),rs.getString("name"),rs.getString("type"),rs.getString("description"),rs.getString("price")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
}
