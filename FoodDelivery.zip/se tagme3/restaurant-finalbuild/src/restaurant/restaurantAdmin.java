/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
public class restaurantAdmin implements Observer {
    private String managerID;
    private String restaurantID;
    private Observable observable=null;
    private String Address;
    private String firstName;
    private String homeNumber;
    private String restaurantAdminid;
    private String lastName;
    private String midName;
    private String phoneNumber;
    private String username;
    private String password;
    private static Integer indexofrestadmin=0;
    public void viewInfo()
    {
        this.toString();
    }
    
    @Override
    public String toString() {
        return "Person{" + "Address=" + Address + ", firstName=" + firstName + ", homeNumber=" + homeNumber + ", id=" + restaurantAdminid + ", lastName=" + lastName + ", midName=" + midName + ", phoneNumber=" + phoneNumber + ", username=" + username + ", password=" + password + '}';
    }

    public restaurantAdmin(String managerID,String restaurantID, String Address, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password) {
        this.managerID = managerID;
        this.restaurantID=restaurantID;
        this.Address = Address;
        this.firstName = firstName;
        this.homeNumber = homeNumber;
        this.restaurantAdminid = setid();
        this.lastName = lastName;
        this.midName = midName;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
    }

    public String getManagerID() {
        return managerID;
    }

    public void setManagerID(String managerID) {
        this.managerID = managerID;
    }

    public String getRestaurantID() {
        return restaurantID;
    }

    public void setRestaurantID(String restaurantID) {
        this.restaurantID = restaurantID;
    }

    public Observable getObservable() {
        return observable;
    }

    public void setObservable(Observable observable) {
        this.observable = observable;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getHomeNumber() {
        return homeNumber;
    }

    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    public String getId() {
        return restaurantAdminid;
    }

    public void setId(String id) {
        this.restaurantAdminid = id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMidName() {
        return midName;
    }

    public void setMidName(String midName) {
        this.midName = midName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    

    public void updateMenu()
    {
        
    }
    public void updateMenuItems()
    {
        
    }
    public void updateRestaurantInfo()
    {
        
    }
    public void viewComments()
    {
        
    }
    public void viewRating()
    {
        
    }
    
    public String setid() {
        String temp="";
        indexofrestadmin++;
        temp="C"+indexofrestadmin.toString();
        this.restaurantAdminid = temp;       
        return temp;
    }
    @Override
    public void update()
    {
        orderStatus();
        unsubscribe();
    }
    
    public void orderStatus()
    {
        System.out.println("anything");
    }
    
    public void unsubscribe()
    {
        observable.removeObserver(this);
    }
    
}
