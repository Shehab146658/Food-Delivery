/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
import java.util.ArrayList;
import javax.swing.*;  
import javax.swing.event.*;  
public class ManagerInfo {    
    JFrame f;    
    ManagerInfo(){    
    f=new JFrame();
 //String managerid,address,firstname,midname,lastname,homenumber,phonenumber;
    
    
       // System.out.println(username);
        //System.out.println(password);
      
          ManagerDB db=new ManagerDB(); 
            ArrayList<SystemManager> s = new ArrayList();
        s= db.getTheCurrentManager();
        String[][] data  = new String[50][9];
        for(int i=0;i<s.size();i++){
        data[i][0] = s.get(i).getManager_id();
        data[i][1] = s.get(i).getAddress();
        data[i][2] = s.get(i).getFirstName();
        data[i][3] = s.get(i).getMidName();
        data[i][4] = s.get(i).getLastName();
        data[i][5] = s.get(i).getHomeNumber();
        data[i][6] = s.get(i).getPhoneNumber();
        data[i][7]=s.get(i).getUsername();
        data[i][8]=s.get(i).getPassword();
        }
            
 
    String column[]={"manager id","address","first name","mid name","last name","home number","phone number","username","password"};         
   
   JTable jt=new JTable(data,column); 
    jt.setBounds(30,40,200,300);          
    JScrollPane sp=new JScrollPane(jt);    
    f.add(sp);          
    f.setSize(300,400);    
    f.setVisible(true);    
}     
public static void main(String[] args) {    
    new ManagerInfo();  
    ManagerDB db=new ManagerDB();
    
    //System.out.println("retrived: "+db.getTheCurrentAdmins());
}    
}  

