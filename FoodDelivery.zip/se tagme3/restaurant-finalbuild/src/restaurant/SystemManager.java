/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.Person_1;
import restaurant.readonly;

/**
 *
 * @author fatma
 */
public class SystemManager extends Person_1{
    
     private String manager_id;
      private String Address;
    private String firstName;
    private String homeNumber;
    private String lastName;
    private String midName;
    private String phoneNumber;
    private String username;
    private String password;
     private  static SystemManager manager ;
     private SystemManager() {
         this.manager=manager;
    }
     public static SystemManager getManager()
     {
         if(manager==null)
         {
             manager=new SystemManager();
         }
         return manager;
     }
    public void viewAllAdministrators(readonly read)
    {
        read.viewAllAdministrators();
       
       
    }
    public void viewAllCustomers(readonly read)
    {
         read.viewAllCustomers();
    }
    public void viewCustomerInfo(readonly read)
    {
         read.viewCustomerInfo();
    }

    public SystemManager(String manager_id, String Address, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password) {
        this.manager_id = manager_id;
        this.Address = Address;
        this.firstName = firstName;
        this.homeNumber = homeNumber;
        this.lastName = lastName;
        this.midName = midName;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
    }

    public String getManager_id() {
        return manager_id;
    }

    public void setManager_id(String manager_id) {
        this.manager_id = manager_id;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getHomeNumber() {
        return homeNumber;
    }

    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMidName() {
        return midName;
    }

    public void setMidName(String midName) {
        this.midName = midName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}