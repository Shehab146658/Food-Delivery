/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
public class Person_1 {
    
    private String Address;
    private String firstName;
    private String homeNumber;
    private int id;
    private String lastName;
    private String midName;
    private String phoneNumber;
    private String username;
    private String password;
    
  public void viewInfo()
  {
      
  }
}
