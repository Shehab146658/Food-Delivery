/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Rawan
 */
public class personR {
    
    private String Adress ;
    private String firstName;
    private String homeNumber;
    private String lastName;
    private String midName;
    private String phoneNumber;
    private String username ;
    private String password ;
    private int id;

    public personR(String Adress, String firstName, String homeNumber, String lastName, String midName, String phoneNumber, String username, String password, int id) {
        this.Adress = Adress;
        this.firstName = firstName;
        this.homeNumber = homeNumber;
        this.lastName = lastName;
        this.midName = midName;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.password = password;
        this.id = id;
    }

    public String getAdress() {
        return Adress;
    }

    public void setAdress(String Adress) {
        this.Adress = Adress;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getHomeNumber() {
        return homeNumber;
    }

    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMidName() {
        return midName;
    }

    public void setMidName(String midName) {
        this.midName = midName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public void viewInfo(){}
    
    
}
