/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Shehab
 */
public class shoppingcartdb {
        private Connection con;
        private final String userName = "root";
        private final String password = "";
        private final String dbName = "restaurant";
        
         public shoppingcartdb() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
         
         public void addshoppingcart(shoppingcart s) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into shoppingcart values('" + s.getCartid() + "', '" + s.getCustomerid()+ "', '" +s.getItemid()+ "', '" +s.getNotes()+"', "+ s.getQuantity()+")");
            System.out.println("shopping cart added");
            
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
         
          public void deleteshoppingcart(String id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from shoppingcart where cartid = '" + id + "'");
            System.out.println("shopping cart deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
          }
          
          public void addnotes(String id, String notes) {
        try {
            Statement stmt = con.createStatement();
           // stmt.executeUpdate("update customerlogin set password = '" + newpass + "' where customerid = '" + id + "'");
            stmt.executeUpdate("update shoppingcart set notes = '" + notes + "' where cartid = '" + id + "'");
            System.out.println("cart updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
          
           public void updateshoppingcart(String id, shoppingcart s) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("update shoppingcart set customerid = '"+s.getCustomerid()+"', itemid ='"+s.getItemid()+"', notes=' "+s.getNotes()+"',quantity = "+s.getQuantity() +" where cartid = '"+s.getCartid()+"'");
            //stmt.executeUpdate("update customerlogin set username = '" + newuser + "' where customerid = '" + id + "'");
           //stmt.executeUpdate("update customer set username = '" + newuser + "' where id = '" + id + "'");
            System.out.println("cart updated");
        } catch (Exception e) {
            System.err.println("DATABASE UPDATE ERROR: " + e.toString());
        }
    }
          
          
          
         public ArrayList<shoppingcart> getallshoppingcarts() {
        ArrayList<shoppingcart> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from shoppingcart");
            while (rs.next()) {
                result.add(new shoppingcart(rs.getString("customerid"), rs.getString("itemid"), rs.getString("notes"), rs.getInt("quantity")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
        
    }
          
         
         
         
         

