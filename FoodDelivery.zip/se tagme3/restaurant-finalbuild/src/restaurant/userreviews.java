/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author fatma
 */
public class userreviews {
    private  int customerid;
    private  int restaurantid;
    private  String review;
   public String displayRating(int rate)
   {
   
       switch (rate){
           case 1:
               return "shit";
               
           case 2:
                return"bad";
                
           case 3:
                return"intermidiate";
                
           case 4:
                return "good";
                
           case 5:
               return"Excellent";
               
            
       }
      return "No rating submitted";
}
   public void addComments(commentsInterface com)
   {
       com.addComments();
   }
   public void addRating()
   {
       
   }
   public void viewComments()
   {
       
   }
}
