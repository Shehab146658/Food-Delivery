/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

import restaurant.menu_component;

/**
 *
 * @author Rawan
 */
public class menu extends menu_component{
    
   
    private  String menu_id;
    private String resturant_id;
    private String  date_update;

    public menu(String menu_id, String resturant_id, String date_update) {
        this.menu_id = menu_id;
        this.resturant_id = resturant_id;
        this.date_update = date_update;
    }

    public String getMenu_id() {
        return menu_id;
    }

    public void setMenu_id(String menu_id) {
        this.menu_id = menu_id;
    }

    public String getResturant_id() {
        return resturant_id;
    }

    public void setResturant_id(String resturant_id) {
        this.resturant_id = resturant_id;
    }

    public String getDate_update() {
        return date_update;
    }

    public void setDate_update(String date_update) {
        this.date_update = date_update;
    }
            
    
    
    
}
