/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class paymentmethoddb {
    private Connection con;
        private final String userName = "root";
        private final String password = "";
        private final String dbName = "restaurant";
        
        public paymentmethoddb() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
        
        public void addpaypalaccount(paypal p) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into paypal values('" + p.getCustomerid() + "', " +" '" +p.getAccountnumber()+ "', " +p.getBalance() +")");
            System.out.println("customer added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
        
        public void addcreditcard(creditcard c) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into creditcard values('" + c.getCreditcardno() + "', '" + c.getCustomerid()+ "', " +c.getBalance() +")");
            System.out.println("credit card added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
        
        public void addcashondelivery(cashondelivery c) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into cashondelivery values(" + c.getAmount() + ", '" + c.getCustomerid()+ "'"+")");
            System.out.println("cash on delivery added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
        
        public void deletepaypal(String id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from paypal where accountnumber = '" + id + "'");
            System.out.println("customer deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
        
        public void deletecreditcard(String id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from creditcard where creditcardno = '" + id + "'");
            System.out.println("customer deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
        
        public void deletecashondelivery(String id) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from cashondelivery where customerid = '" + id + "'");
            System.out.println("customer deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
        
         public ArrayList<paypal> getpaypaltrans() {
        ArrayList<paypal> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from paypal");
            while (rs.next()) {
                result.add(new paypal(rs.getString("customerid"), rs.getString("accountnumber"), rs.getFloat("balance")));
               // result.add(new customer(rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("phonenumber"),rs.getString("homenumber"),rs.getString("address"),rs.getString("username"),rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
         
         public ArrayList<creditcard> getcreditcardtrans() {
        ArrayList<creditcard> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from creditcard");
            while (rs.next()) {
                result.add(new creditcard(rs.getString("creditcardno"), rs.getString("customerid"), rs.getFloat("balance")));
               // result.add(new paypal(rs.getString("customerid"), rs.getString("restaurantid"), rs.getString("accountnumber"), rs.getFloat("value"), rs.getFloat("balance")));
               // result.add(new customer(rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("phonenumber"),rs.getString("homenumber"),rs.getString("address"),rs.getString("username"),rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
         
         public ArrayList<cashondelivery> getcashondeliverytrans() {
        ArrayList<cashondelivery> result = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from cashondelivery");
            while (rs.next()) {
                result.add(new cashondelivery(rs.getFloat("amount"), rs.getString("customerid")));
               // result.add(new paypal(rs.getString("customerid"), rs.getString("restaurantid"), rs.getString("accountnumber"), rs.getFloat("value"), rs.getFloat("balance")));
               // result.add(new customer(rs.getString("firstname"), rs.getString("midname"),rs.getString("lastname"),rs.getString("phonenumber"),rs.getString("homenumber"),rs.getString("address"),rs.getString("username"),rs.getString("password")));
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return result;
    }
        
       
        
}
