/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;

/**
 *
 * @author Shehab
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class testdb {
    test t = new test("hassan", "hasanola");
        private Connection con;
        private final String userName = "root";
        private final String password = "";
        private final String dbName = "restaurant";

         public testdb() {
        try {
            //Loading the jdbc driver
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Get a connection to database
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (Exception e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
         
          public void addsubject(test t) {
        try {
            Statement stmt = con.createStatement();
           // stmt.executeUpdate("insert into students values('" + s.getName() + "', " + s.getGPA() + ")");
           stmt.executeUpdate("insert into test values ('"+t.getUsername()+"','"+t.getPassword()+"')");
            System.out.println("test added");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }

}
